#!/bin/bash
# Main initialization script for MyChain blockchain
# This will always initialize with the default configuration

# Run the default initialization
./scripts/init_default.sh